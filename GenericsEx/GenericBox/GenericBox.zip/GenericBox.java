package Q_GenericsEx.GenericBox;


public class GenericBox<T> {
    private T data;

    public GenericBox(T data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return this.data.getClass().getName() + ": " + this.data;
    }
}
