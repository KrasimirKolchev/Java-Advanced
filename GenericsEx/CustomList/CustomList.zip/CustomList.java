package Q_GenericsEx.CustomList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;

public class CustomList<T extends Comparable<T>> {
    private List<T> tList;

    public CustomList() {
        this.tList = new ArrayList<>();
    }

    public void add(T element) {
        this.tList.add(element);
    }

    public T remove(int index) {
        return this.tList.remove(index);
    }

    public boolean contains(T element) {
        return this.tList.contains(element);
    }

    public void swap(int first, int second) {
        Collections.swap(this.tList, first, second);
    }

    public int countGreaterThan(T element) {
        return (int) this.tList.stream().filter(value -> value.compareTo(element) > 0)
                .count();
    }

    public T getMax() {
        return Collections.max(this.tList);
    }

    public T getMin() {
        return Collections.min(this.tList);
    }

    public static <T extends Comparable<T>> void printList(CustomList tList) {
        tList.tList.stream().forEach(System.out::println);
    }

    public void forEach(Consumer<T> consumer) {
        for (T element : tList) {
            consumer.accept(element);
        }
    }

    public int size() {
        return this.tList.size();
    }

    public T get(int index) {
        return  this.tList.get(index);
    }

}
