package Q_GenericsEx.CountMethod;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        int n = Integer.parseInt(reader.readLine());
        List<CountBox<String>> boxes = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            String text = reader.readLine();
            CountBox<String> countBox = new CountBox<>(text);

            boxes.add(countBox);
        }

        String value = reader.readLine();

        int count = countGreater(boxes, value);
        System.out.println(count);
    }

    private static <T extends Comparable<T>> int countGreater(List<CountBox<T>> boxes, T value) {
        int count = 0;
        for (CountBox<T> box : boxes) {
            if (box.getData().compareTo(value) > 0) {
                count++;
            }
        }
        return count;
    }
}
