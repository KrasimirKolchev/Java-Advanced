package Q_GenericsEx.CountMethod;


public class CountBox<T extends Comparable<T>> {
    private T data;

    public CountBox(T data) {
        this.data = data;
    }

    public T getData() {
        return data;
    }
}
