package S_IteratorsAndComparatorsEx.ListyIterator;

import java.util.ArrayList;
import java.util.List;

public class ListyIterator {
    private static final int INITIAL_INDEX = 0;

    private List<String> text;
    private int index;

    public ListyIterator(List<String> text) {
        this.text = text;
        this.index = INITIAL_INDEX;
    }

    public boolean move() {
        if (hasNext()) {
            this.index += 1;
            return true;
        }
        return false;
    }

    public boolean hasNext() {
        if (this.index + 1 < text.size()) {
            return true;
        }
        return false;
    }

    public void print() {
        if (this.index < text.size()) {
            System.out.println(this.text.get(this.index));
        } else {
            System.out.println("Invalid Operation!");
        }

    }
}
